const { handler } = require('./app');

exports.handler = handler;
